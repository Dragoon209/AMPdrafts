'use strict';

module.exports = [
    {command: 'statue', label: 'Statue', position: new Vector3f(3695.90, 1025.36, 1423.11)},
    {command: 'boomisland', label: 'Boom Island', position: new Vector3f(-13330.90, 1026.59, 14827.60)},
    {command: 'airfield', label: 'Airfield', position: new Vector3f(-4902.63, 1175.48, -7670.74)},
    {command: 'military', label: 'Military Base', position: new Vector3f(7845.71, 2957.11, -6442.56)},
    {command: 'volcano', label: 'Volcano', position: new Vector3f(-12753.68, 1855.55, -12215.02)}
];
