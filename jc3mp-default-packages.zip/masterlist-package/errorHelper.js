'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ErrorHelper = undefined;

var _customLogger = require('custom-logger');

var _customLogger2 = _interopRequireDefault(_customLogger);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const log = _customLogger2.default.config({ level: process.env.NODE_ENV === 'production' });

const descriptions = [{
  message: 'invalid auth_key',
  type: 'PUT',
  description: 'You are using an invalid auth key. Check your configuration. Follow the guide on https://just-cause.mp/download-masterlist to get one.'
}, {
  message: 'invalid auth_key',
  type: 'POST',
  description: 'You are using an invalid auth key. Your key might have been invalidated. ' + 'The masterlist might have just restarted and is waiting for you to re-announce the server.'
}, {
  message: /ECONNREFUSED/,
  type: '*',
  description: 'Your firewall might block access to the masterlist ' + 'or the masterlist might be down right now.'
}, {
  message: /E(.*?)TIMEDOUT/,
  type: '*',
  description: 'The masterlist is unreachable. Either your firewall ' + 'blocks access or the masterlist is experiencing problems.'
}, {
  message: 'internal server error',
  type: '*',
  description: 'The masterlist is having trouble handling requests ' + 'right now. the developers have been notified.'
}];

class ErrorHelper {
  static describe(message, type) {
    const possibleDescriptions = descriptions.filter(d => message.match(d.message) !== null);
    let exactMatch = possibleDescriptions.filter(d => type === d.type)[0];
    if (!exactMatch) {
      exactMatch = possibleDescriptions.filter(d => d.type === '*')[0];
    }

    if (possibleDescriptions.length === 0) {
      log.warn(`error helper: no description found for ${type}: ${message}`);
      return;
    }

    if (exactMatch) {
      log.error(`error helper: ${exactMatch.description}`);
    } else {
      log.error('error helper: possible explanations:');
      possibleDescriptions.forEach(d => log.error(`error helper: (${d.type}) ${d.description}`));
    }
  }
}
exports.ErrorHelper = ErrorHelper;